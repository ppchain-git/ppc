<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="zh-CN">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>转出</title>
<link rel="stylesheet" href="/Public/Home/css/style.css">
<link rel="stylesheet" href="/Public/Home/css/digital.css">
<link rel="stylesheet" href="/Public/Home/css/float.css">
<script type="text/javascript" src="/Public/Home/js/jquery-1.9.1.min.js" ></script>

<script type="text/javascript" src="/Public/Home/js/index.js"></script>
<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>

<body>
	<div class="header">
	    <div class="header_l">
	    <a href="<?php echo U('Index/index');?>"><img src="/Public/Home/images/jiant.png" alt=""></a>
	    </div>
	    <div class="header_c"><h2>转出</h2></div>
	    <div class="header_r"><a href="<?php echo U('Index/trans',array('type'=>1));?>">记录</a></div>
	</div>

       <div class="big_width100" style="margin-top:52px;">
			<div class="fill_sty">
				<p>转出数量</p>
	       		<input type="text" name="other_account" class="paynums" placeholder="请输入转出数量" style="width:70%;padding-left: 5px;">
			</div>
	        <div class="fill_sty">
	       	<p>转出地址</p>
	       		<input type="text" name="other_account" class="moneyadd" placeholder="手机/UID/钱包地址" style="width:70%;padding-left: 5px;">
			</div>
			<div class="buttonGeoup">
	       		<a href="javascript:void(0)" class="not_next" id="operConfirm">确定</a>
			</div>

		   <!--浮动层SS-->
		   <div class="ftc_wzsf" >
			   <div class="srzfmm_box">
					<div class="qsrzfmm_bt clear_wl">
					   <img style="padding: 6px 0;" src="/Public/Home/images/xx_03.jpg" class="tx close fl">
					   <span class="fl" style="padding: 15px 5px;">请输入支付密码</span></div>
					<div class="zfmmxx_shop">
					   <div class="mz" style="margin-top: 5px;margin-bottom: 10px;"></div>
					   <div class="zhifu_price"></div>
					</div>
					<ul class="mm_box">
					   <li></li><li></li><li></li><li></li><li></li><li></li>
					</ul>
					<input type="hidden" class="coin_id">
			   </div>
			   <div class="numb_box">
				   <div class="xiaq_tb">
					   <img src="/Public/Home/images/jftc_14.jpg" height="10"></div>
				   <ul class="nub_ggg">
					   <li><a href="javascript:void(0);" class="zf_num">1</a></li>
					   <li><a href="javascript:void(0);" class="zj_x zf_num">2</a></li>
					   <li><a href="javascript:void(0);" class="zf_num">3</a></li>
					   <li><a href="javascript:void(0);" class="zf_num">4</a></li>
					   <li><a href="javascript:void(0);" class="zj_x zf_num">5</a></li>
					   <li><a href="javascript:void(0);" class="zf_num">6</a></li>
					   <li><a href="javascript:void(0);" class="zf_num">7</a></li>
					   <li><a href="javascript:void(0);" class="zj_x zf_num">8</a></li>
					   <li><a href="javascript:void(0);" class="zf_num">9</a></li>
					   <li><a href="javascript:void(0);" class="zf_empty">清空</a></li>
					   <li><a href="javascript:void(0);" class="zj_x zf_num">0</a></li>
					   <li><a href="javascript:void(0);" class="zf_del">删除</a></li>
				   </ul>
			   </div>
			   <div class="hbbj"></div>
		   </div>
		   <!--浮动层EE-->
	   </div>

	<script type="text/javascript">
        $('#operConfirm').on('click', function(){
            var paynums=($('.paynums').val());//支付金额
			if(paynums < 0.01){
                msg_alert('请输入正确的转账金额');
                return;
			}
			var moneyadd = $('.moneyadd').val();
			if(moneyadd == ''){
			    msg_alert('请输入手机/UID/钱包地址');
			}
			
			$.ajax({
				url:"<?php echo U('Index/checkuser');?>",
				type:'post',
				data:{'moneyadd':moneyadd,'paynums':paynums},
				datatype:'json',
				success:function (mes) {
					if(mes.status == 1){
                        var uinfo = mes.message;
						$('.mz').text('转出 PPC 资产到：[ ' +uinfo.uname+ ' ]');
					    $('.zhifu_price').text('' + paynums);
						$('.coin_id').val(uinfo.coin_id);
                        $(".ftc_wzsf").show();
                    }else{
						msg_alert(mes.message);
					}
                }
			})
        });

        //获取数据传值
        function Getvalue() {
            var data={'moneyadd':moneyadd,'paynums':paynums};
            return data;
        }

        //关闭浮动
        $(".close").click(function(){
            $(".ftc_wzsf").hide();
            $(".mm_box li").removeClass("mmdd");
            $(".mm_box li").attr("data","");
            i = 0;
        });
        //数字显示隐藏
        $(".xiaq_tb").click(function(){
            $(".numb_box").slideUp(500);
        });
        $(".mm_box").click(function(){
            $(".numb_box").slideDown(500);
        });
        //----
        var i = 0;
        $(".nub_ggg li .zf_num").click(function(){
            if(i<6){
                $(".mm_box li").eq(i).addClass("mmdd");
                $(".mm_box li").eq(i).attr("data",$(this).text());
                i++
                if (i==6) {
                    setTimeout(function(){
                        var pwd = "";
                        $(".mm_box li").each(function(){
                            pwd += $(this).attr("data");
                        });
                        //ajax提交密码以及参数
                        var paynums=($('.paynums').val());//支付金额
                        var moneyadd = $('.moneyadd').val();
						var coin_id = $('.coin_id').val();
                        $.ajax({
                            url:"<?php echo U('Index/wegetin');?>",
                            type:'post',
                            data:{'paynums':paynums,'moneyadd':moneyadd,'pwd':pwd,'coinid':coin_id},
                            datatype:'json',
                            success:function (mes) {
                                if(mes.status == 1){
                                    msg_alert(mes.message,mes.url);
                                    $(".ftc_wzsf").hide();
                                    $(".mm_box li").removeClass("mmdd");
                                    $(".mm_box li").attr("data","");
                                    i = 0;
                                    $('.paynums').val('');//支付金额
                                    $('.moneyadd').val('');
                                }else{
                                    msg_alert(mes.message);
                                    $(".mm_box li").removeClass("mmdd");
                                    $(".mm_box li").attr("data","");
                                    i = 0;
                                }
                            }
                        })
                    },100);
                };
            }
        });

        $(".nub_ggg li .zf_del").click(function(){
            if(i>0){
                i--
                $(".mm_box li").eq(i).removeClass("mmdd");
                $(".mm_box li").eq(i).attr("data","");
            }
        });

        $(".nub_ggg li .zf_empty").click(function(){
            $(".mm_box li").removeClass("mmdd");
            $(".mm_box li").attr("data","");
            i = 0;
        });
        // });
	</script>


</body>
</html>