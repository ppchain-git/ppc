<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="zh-CN" >
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>转账记录</title>
<link rel="stylesheet" href="/Public/Home/css/style.css">
<link rel="stylesheet" href="/Public/Home/css/digital.css">
<script type="text/javascript" src="/Public/Home/js/jquery-1.9.1.min.js" ></script>

<body class="bg96">
<div class="header">
	<div class="header_l">
		<a href="<?php echo U('Index/index');?>"><img src="/Public/Home/images/jiant.png" alt=""></a>
	</div>
	<div class="header_c"><h2>记录</h2></div>
	<div class="header_r"></div>
</div>

<div class="undone_order">
	<div class="undone_order_titel clear_wl">
		<a href="<?php echo U('Index/trans',array('type'=>1));?>" <?php if(($type) == "1"): ?>class="undone_OT_l fl noe" <?php else: ?> class="undone_OT_l fl"<?php endif; ?> >
		转出
		</a>
		<a href="<?php echo U('Index/trans');?>" <?php if(($type) == "1"): ?>class="undone_OT_r fr" <?php else: ?> class="undone_OT_r fr noe"<?php endif; ?>>
		转入
		</a>
	</div>
</div>

<div id="wrapper" style="top: 95px;">
	<div class="scrollera">
		<ul>
		<?php if($Chan_info):?>
			<?php if(is_array($Chan_info)): foreach($Chan_info as $key=>$v): ?><li>
					<p class="dig_re_p" style="font-size: 14px;color: #000;margin-bottom: 5px;"><?php if(($type) == "1"): ?>转出<?php else: ?>转入(<?php echo ($v['pay_id']); ?>)<?php endif; if(($type) == "1"): ?>(<?php echo ($v['uid']); ?>)<?php endif; ?>&nbsp; <span><?php echo ($v['get_nums']); ?> <?php if(cookie('think_language') == 'en-us'): echo ($v['en_coin_name']); else: echo ($v['coin_name']); endif; ?></span> </p>
					<!-- <p><?php if(($type) == "1"): ?>昵称：<?php echo ($v['outinfo']); endif; ?>&nbsp;<span <?php if($type == 0): ?>style="float:left"<?php endif; ?>><?php echo ($v['get_timeymd']); ?> <?php echo ($v['get_timedate']); ?></span></p> -->
					<p>昵称：<?php if(($type) == "1"): echo ($v['outinfo']); ?> <?php else: echo ($v['ininfo']); endif; ?>&nbsp;<span><?php echo ($v['get_timeymd']); ?> <?php echo ($v['get_timedate']); ?></span></p>
				</li><?php endforeach; endif; ?>
		<?php else:?>
		<span style="width: 100%;padding: 20px 0;text-align: center;text-align: center;display: block;font-size: 14px;">亲，找不到相关记录哦~</span>
		<?php endif;?>
		</ul>
	</div>
</body>

</html>