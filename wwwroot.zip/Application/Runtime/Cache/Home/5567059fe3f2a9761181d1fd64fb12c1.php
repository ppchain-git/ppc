<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="zh-CN">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php echo (L("zcxmuzxs")); ?></title>
<link rel="stylesheet" href="__WCSS__/style.css">
<link rel="stylesheet" href="__WCSS__/digital.css">
<script src="__WJS__/jquery1.11.1.min.js"></script>
<script type="text/javascript" src="__COM__/layer/layer.js"></script>
<link rel="stylesheet" href="__LAYERUI__/css/layui.css">
<script src="__LAYERUI__/layui.js"></script>
<!--动画-->
<link rel="stylesheet" href="__WCSS__/donghua_r.css">
<script src="__WJS__/donghua.js"></script>
<!--动画结束-->
<body class="bg96">
	
	<div class="header">
	    <div class="header_l">
	    <a href="<?php echo U('Turntable/index');?>"><img src="__WIMG__/jiant.png" alt=""></a>
	    </div>
	    <div class="header_c"><h2><?php echo (L("zcxmuzxs")); ?></h2></div>
	    <div class="header_r"><a href="<?php echo U('Turntable/Crowdrecords');?>"><?php echo (L("zcxfijlu")); ?></a></div>
	</div>

       <div class="big_width100" style="margin:0px;">

            <div class="zy_topul">
            	<ul class="clear_wl">
	    			<li>
	    				<a href="<?php echo U('Turntable/Crowd');?>?no_jump">
	    					<img src="__WIMG__/zc0-iocn.png" alt="">
	    					<p class="nop"><?php echo (L("yrz")); ?></p>
	    				</a>
	    				<div class="nj"></div>
	    			</li>
	    			<li>
	    				<a href="<?php echo U('Turntable/Crowd',array('step'=>1));?>?no_jump">
	    					<img src="__WIMG__/zc1-iocn.png" alt="">
	    					<p><?php echo (L("jxz")); ?></p>
	    				</a>
	    				<div class="nj"></div>
	    			</li>
	    			<li>
	    				<a href="<?php echo U('Turntable/Crowd',array('step'=>2));?>?no_jump">
	    					<img src="__WIMG__/zc2-iocn.png" alt="">
	    					<p><?php echo (L("yjs")); ?></p>
	    				</a>
	    				<div class="nj"></div>
	    			</li>
	    		</ul>
            </div>
<style>
.zcweikais{width:100%;box-sizing:border-box;padding:0;}
.zc-list{margin-bottom:15px;position:relative;padding: 8px 3%;}		
</style>
            <div class="zcweikais">
			<?php if($list):?>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><!-- 这个是一个大的div ，这个名字还没有取，你自己取-->
				<div class="zc-list">
            	<div class="zcweikais_top clear_wl">
            		<img src="/Uploads/<?php echo ($vo["coin_logo"]); ?>" class="zcimg">
            		<div class="zcweikais_topwz" style="display: inline-block;">
            			<h3><?php echo ($vo["coin_name"]); ?></h3>
            			<p class="zcxwz"><?php echo (L("yhl_mgidxg")); ?><span><?php echo ($vo["coin_limit"]); ?></span><?php echo (L("yhl_mei")); ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (L("zcsfangbli")); ?><span><?php echo ($vo["coin_ratio"]); ?></span>%</p>
            			<p><?php echo (L("zcjsiubz")); ?><span><?php echo ($vo["pay_type"]); ?></span></p>
            		</div>
            		<div class="zcwksshij">
            			<img src="__WIMG__/naozz.png"><?php echo (date("Y-m-d",$vo["start_time"])); ?>
            		</div>

            	</div >
            	<div class="zcweikais_mid clear_wl">
            		<ul>
            			<li class="zcweikais_mid_lia" style="width: 25%;"><p><?php echo (L("zcms")); ?><br/><span><?php echo ((int)($vo["coin_num"] / 10000 )); echo (L("yhl_wan")); ?></span></p></li>
            			<li class="zcweikais_mid_lib" style="width: 50%;"><p><?php echo (L("jg")); ?><br/>1 <?php echo ($vo["coin_type"]); ?> = <span><?php echo ($vo["coin_price"]); ?></span> <?php echo ($vo["pay_type"]); ?></p></li>
            			<li class="zcweikais_mid_lic" style="width: 25%;"><p><?php echo (L("sysj")); ?><br/><span class="hse"><?php echo (L("zcyurez")); ?></span></p></li>
            		</ul>
            	</div>

            	<div class="zcweikais_bottom clear_wl">
					<div class="zcweikais_bottom_jdzb">
						 <div class="layui-progress layui-progress-big " lay-showPercent="true">
						   <div class="layui-progress-bar layui-bg-blue" lay-percent="0%"></div>
						</div>
					</div>
					<a href="#" class="zcweikais_bottom_jdzb_a"><?php echo (L("ljgm")); ?></a>
            	</div>
				</div>
				<div style="background:#f1f1f1;height:10px;width:100%;margin-top:20px;"></div><?php endforeach; endif; else: echo "" ;endif; ?>
			<?php else:?>
			<span style="color:#666;text-align: center;display: inline-block;width: 100%;margin-top: 10px;font-size: 14px;"><?php echo (L("mzdxgjl")); ?></span>
			<?php endif;?>
            </div>
	   </div>

		<script>
			layui.use('element', function(){
			  var element = layui.element;
			});
		</script>
</body>

</html>